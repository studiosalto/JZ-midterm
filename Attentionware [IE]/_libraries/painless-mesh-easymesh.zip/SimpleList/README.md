# SimpleList

Forked for the sake of using it as a git submodule  
Original repo: https://github.com/blackhack/ArduLibraries  
Doc: https://github.com/blackhack/ArduLibraries/tree/master/SimpleList/examples
